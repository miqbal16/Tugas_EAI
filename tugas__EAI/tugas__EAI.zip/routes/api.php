<?php

use App\Models\Item;
use App\Models\divisi;
use App\Models\karyawan;
use App\Models\kehadiran;
use App\Models\penggajian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

//DIVISI
Route::get('divisi', function() {
    return divisi::all();
});
Route::get('divisi/{id_divisi}', function(divisi $id_divisi) {
    return $id_divisi;
});
Route::post('divisi', function() {
    return divisi::create(request()->all());
});
Route::delete('divisi/{id_divisi}', function(divisi $id_divisi) {
    return $id_divisi->delete();
});

//KARYAWAN
Route::get('karyawan', function() {
    return karyawan::all();
});
Route::get('karyawan/{NIP}', function(karyawan $NIP) {
    return $NIP;
});
Route::post('karyawan', function() {
    return karyawan::create(request()->all());
});
Route::delete('karyawan/{NIP}', function(karyawan $NIP) {
    return $NIP->delete();
});
Route::put('karyawan/{NIP}', function(Request $request, $NIP) {
    $karyawan = karyawan::findOrFail($NIP);
    $karyawan->update($request->all());

    return $karyawan;
});

//PENGGAJIAN
Route::get('penggajian', function() {
    return penggajian::all();
});
Route::post('penggajian', function() {
    return penggajian::create(request()->all());
});
Route::delete('penggajian/{id_penggajian}', function(penggajian $id_penggajian) {
    return $id_penggajian->delete();
});
Route::put('penggajian/{id_penggajian}', function(Request $request, $id_penggajian) {
    $penggajian = penggajian::findOrFail($id_penggajian);
    $penggajian->update($request->all());

    return $penggajian;
});
// Route::put('penggajian/{id_penggajian}', function() {
//     return penggajian::update(request());
// });

//KEHADIRAN
Route::get('kehadiran', function() {
    return kehadiran::all();
});
Route::get('kehadiran/{id_kehadiran}', function(kehadiran $id_kehadiran) {
    return $id_kehadiran;
});
Route::post('kehadiran', function() {
    return kehadiran::create(request()->all());
});
Route::delete('kehadiran/{id_kehadiran}', function(kehadiran $id_kehadiran) {
    return $id_kehadiran->delete();
});
